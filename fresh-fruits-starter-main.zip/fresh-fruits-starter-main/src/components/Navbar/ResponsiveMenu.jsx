import React from "react";

const ResponsiveMenu = () => {
  return <div>ResponsiveMenu</div>;
};

export default ResponsiveMenu;
