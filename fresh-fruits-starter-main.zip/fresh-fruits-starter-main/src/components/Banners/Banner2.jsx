import React from "react";

const Banner2 = () => {
  return <div>Banner2</div>;
};

export default Banner2;
