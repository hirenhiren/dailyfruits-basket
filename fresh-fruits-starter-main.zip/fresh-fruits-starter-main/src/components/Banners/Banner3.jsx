import React from "react";

const Banner3 = () => {
  return <div>Banner3</div>;
};

export default Banner3;
