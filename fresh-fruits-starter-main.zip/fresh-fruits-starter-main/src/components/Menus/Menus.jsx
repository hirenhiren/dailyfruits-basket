import React from "react";

const Menus = () => {
  return <div>Menus</div>;
};

export default Menus;
